<?php
    include("config.php");
    $irpg_page_title = "Thank's";
    include("header.php");
?>

    <h1>Thank you</h1>
    <p class="lead">Thank you to the following sites, services and people who made this site possible</p>
    
    <h2>Twitter Bootstrap</h2>
    <p>Sleek, intuitive, and powerful front-end framework for faster and easier web development.</p>
    
    <h2>GeekSoc</h2>
    <p>