<?php

$admin_email="adamus1red@gmail.com";
$admin_nick="GeekSoc";

// nickname of your bot
$irpg_bot="IdleBot";

// your game's server
$irpg_network="irc.geeksoc.org";

// your game's channel
$irpg_chan="#IdleRPG";

// full or relative pathname to the DBs:

// character database
$irpg_db="/home/amcghie/idlerpg/irpg.db";

// time modifiers file
$irpg_mod="/home/amcghie/idlerpg/modifiers.txt";

// active quest info file
$irpg_qfile="/home/amcghie/idlerpg/questinfo.txt";

// image to use for the top logo
$irpg_logo="idlerpg.png";

// directory in which your site is located from the root directory. my site
// is http://jotun.ultrazone.org/g7/, so it's "/g7/"
$BASEURL="/~amcghie/dev/";

// width-wise dimension of your map file
$mapx = 500;

// length-wise dimension of your map file
$mapy = 500;

$net_name = "GeekSoc";
$net_url = "http://geeksoc.org/";
$irpg_chan_url = "irc://irc.geeksoc.org/idlerpg";
?>
